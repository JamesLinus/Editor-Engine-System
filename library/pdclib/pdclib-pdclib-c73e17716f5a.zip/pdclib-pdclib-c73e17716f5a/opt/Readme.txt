These are implementation options, selected for compilation by setting
PDCLIB_OPTIONS in platform/*/Config.jam.

Alternatively, you can just copy the source files into the appropriate
directories of the main codebase before compiling. But for the time
being, opt/ is where we (as "upstream PDCLib") will maintain them.
