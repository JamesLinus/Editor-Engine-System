#include <stdio.h>

// This test program is provided to enable a quick test of PDCLib's console I/O
// functions

int main(int argc, char** argv)
{
    printf("Hello world\n");
    return 0;
}
